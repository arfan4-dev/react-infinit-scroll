"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getPhotos";
exports.ids = ["pages/api/getPhotos"];
exports.modules = {

/***/ "pexels":
/*!*************************!*\
  !*** external "pexels" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("pexels");

/***/ }),

/***/ "(api)/./pages/api/getPhotos.js":
/*!********************************!*\
  !*** ./pages/api/getPhotos.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var pexels__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! pexels */ \"pexels\");\n/* harmony import */ var pexels__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(pexels__WEBPACK_IMPORTED_MODULE_0__);\n\nconst client = (0,pexels__WEBPACK_IMPORTED_MODULE_0__.createClient)(process.env.API_KEY);\nconst handler = async (req, res)=>{\n    const { method , query: { query , page  } ,  } = req;\n    if (method !== \"GET\") return res.status(405).send(\"Method not allowed\");\n    if (!query || !page) return res.status(400).send(\"Bad request\");\n    const result = await client.photos.search({\n        query,\n        page\n    });\n    console.log(\"result:\", result);\n    const photos = result.photos.map((photo)=>photo.src.large\n    );\n    return res.send(photos);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0UGhvdG9zLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFxQztBQUVyQyxNQUFNQyxNQUFNLEdBQUdELG9EQUFZLENBQUNFLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxPQUFPLENBQUM7QUFFaEQsTUFBTUMsT0FBTyxHQUFHLE9BQU9DLEdBQUcsRUFBRUMsR0FBRyxHQUFLO0lBQ25DLE1BQU0sRUFDTEMsTUFBTSxHQUNOQyxLQUFLLEVBQUUsRUFBRUEsS0FBSyxHQUFFQyxJQUFJLEdBQUUsS0FDdEIsR0FBR0osR0FBRztJQUVQLElBQUlFLE1BQU0sS0FBSyxLQUFLLEVBQUUsT0FBT0QsR0FBRyxDQUFDSSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUV2RSxJQUFJLENBQUNILEtBQUssSUFBSSxDQUFDQyxJQUFJLEVBQUUsT0FBT0gsR0FBRyxDQUFDSSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQyxhQUFhLENBQUM7SUFFL0QsTUFBTUMsTUFBTSxHQUFHLE1BQU1aLE1BQU0sQ0FBQ2EsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRU4sS0FBSztRQUFFQyxJQUFJO0tBQUUsQ0FBQztJQUMzRE0sT0FBTyxDQUFDQyxHQUFHLENBQUMsU0FBUyxFQUFDSixNQUFNLENBQUM7SUFDNUIsTUFBTUMsTUFBTSxHQUFHRCxNQUFNLENBQUNDLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDLENBQUNDLEtBQUssR0FBS0EsS0FBSyxDQUFDQyxHQUFHLENBQUNDLEtBQUs7SUFBQSxDQUFDO0lBRTVELE9BQU9kLEdBQUcsQ0FBQ0ssSUFBSSxDQUFDRSxNQUFNLENBQUM7Q0FDdkI7QUFFRCxpRUFBZVQsT0FBTyIsInNvdXJjZXMiOlsid2VicGFjazovL2luZmluaXRlLXNjcm9sbC1nYWxsZXJ5Ly4vcGFnZXMvYXBpL2dldFBob3Rvcy5qcz82MDYwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ3BleGVscydcblxuY29uc3QgY2xpZW50ID0gY3JlYXRlQ2xpZW50KHByb2Nlc3MuZW52LkFQSV9LRVkpXG5cbmNvbnN0IGhhbmRsZXIgPSBhc3luYyAocmVxLCByZXMpID0+IHtcblx0Y29uc3Qge1xuXHRcdG1ldGhvZCxcblx0XHRxdWVyeTogeyBxdWVyeSwgcGFnZSB9LFxuXHR9ID0gcmVxICAgICAgICBcbiAgXG5cdGlmIChtZXRob2QgIT09ICdHRVQnKSByZXR1cm4gcmVzLnN0YXR1cyg0MDUpLnNlbmQoJ01ldGhvZCBub3QgYWxsb3dlZCcpXG5cblx0aWYgKCFxdWVyeSB8fCAhcGFnZSkgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5zZW5kKCdCYWQgcmVxdWVzdCcpXG5cblx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LnBob3Rvcy5zZWFyY2goeyBxdWVyeSwgcGFnZSB9KVxuY29uc29sZS5sb2coJ3Jlc3VsdDonLHJlc3VsdClcblx0Y29uc3QgcGhvdG9zID0gcmVzdWx0LnBob3Rvcy5tYXAoKHBob3RvKSA9PiBwaG90by5zcmMubGFyZ2UpXG5cblx0cmV0dXJuIHJlcy5zZW5kKHBob3Rvcylcbn1cblxuZXhwb3J0IGRlZmF1bHQgaGFuZGxlclxuIl0sIm5hbWVzIjpbImNyZWF0ZUNsaWVudCIsImNsaWVudCIsInByb2Nlc3MiLCJlbnYiLCJBUElfS0VZIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsInF1ZXJ5IiwicGFnZSIsInN0YXR1cyIsInNlbmQiLCJyZXN1bHQiLCJwaG90b3MiLCJzZWFyY2giLCJjb25zb2xlIiwibG9nIiwibWFwIiwicGhvdG8iLCJzcmMiLCJsYXJnZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/getPhotos.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getPhotos.js"));
module.exports = __webpack_exports__;

})();